
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
    <title>Admin Session</title>
</head>

<body>
   
    <nav>
        <ul class="navbar">
             <li><a href="managePatient.php">Manage Patients</a></li>
            <li><a href="manageOrders.php">Manage Orders</a></li>
			  <li><a href="manageItems.php">Manage Medicines</a></li>
			<li><a class="active" href="AdminSession.php">Dashboard</a></li>
        </ul>
    </nav>
<br/> <br/>


<div class="container">

<h1 style="color:#7FBD40;"> Manage Items </h1>
<br>	
<hr size="2" color="green">

<form  method="post" action="addProduct.php" enctype="multipart/form-data" >
	
	
	<p>
	Medicine Details :
	<input type="text" name="txtName" style="width:200px" class="form-control" required />
	</p>
	
	<p>
	Medicine Price (OMR):
	<input type="txt" name="txtPrice" style="width:200px" class="form-control" required />
	</p>
	<p>
	Quantity:
	
	<input type="txt" name="txtQty" style="width:200px" class="form-control" required />
	
	</p>
	<p >
	Upload Photos:
	
	<input type="file" name="uploadfile" required style="width:200px;" value="" />
	
	</p>
	<p>
	
	<input type="submit" name="add"  value="Add" class="btn btn-primary" />	
	</p>
</form>

</div>
<br/>
<div class='dvx'>	
 
<h2> All List Medicines</h2>
<br/>
<hr size="2" color="green">

  <?php
include 'conn.php';
$conn=OpenCon();
if(! $conn ) {
    die('Could not connect: ' . mysql_error());
}

$sql = "SELECT * FROM medicines";

 $retval = mysqli_query( $conn,$sql);

echo"<table border='1px solid green' style='color:green' cellspacing='10' cellpadding='5' >";
echo"<tr style='background-color: #D6EEEE;'>";
   echo"<td>ID</td>";  
   echo"<td>Medicnes Details</td>";
   echo"<td>Stored date</td>";
    echo"<td>Price</td>";
	echo"<td>Qty</td>";
	echo"<td>Photo</td>";
	 echo"<td>Edit</td>";
	 echo"<td>Delete</td>";
	echo"</tr>";
						
while($record=mysqli_fetch_array($retval))
{
     $field1=$record['medicinesID'];
	 $field2=$record['medicinesDetails'];
	 $field3=$record['storedDate'];
	 $field4=$record['medicinesPrice'];
	  $field5=$record['qty'];
	   $field6=$record['photo'];
	 
	 		
echo"<form action='manageProd.php' method='Post'>";

   echo"<tr>";
   echo"<td>"."<input type=text name=txt class=txt readonly value=".$field1.">"."</td>";
   echo"<td>"."<input type=text name=txt1 class=txt  value=".$field2.">"."</td>";
   echo"<td>"."<input type=text name=txt2 class=txt  value=".$field3.">"."</td>";
   echo"<td>"."<input type=text name=txt3 class=txt  value=".$field4.">"."</td>";
    echo"<td>"."<input type=text name=txt4 class=txt  value=".$field5.">"."</td>";
    echo"<td><img src=".$field6." width=70px height=70px /></td>";

   echo"<td><input type=submit name=edit style='width:25;height:20px; border:2px solid white; font-size:medium; background-color:green; color:white' value='Edit' ></td>";
   
   echo"<td><input type=submit name=delete  style='width:25;height:20px; border:2px solid white; font-size:medium; background-color:red; color:white' value='Delete' ></td>";
    echo"</tr>";
	echo"</form>";
}	
echo"</table>";
?>

</div>



 </body>
</html>


