
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
    <title>Admin Session</title>
</head>

<body>
   
    <nav>
        <ul class="navbar">
             <li><a href="managePatient.php">Manage Patients</a></li>
            <li><a href="manageOrders.php">Manage Orders</a></li>
			  <li><a href="manageItems.php">Manage Medicines</a></li>
			<li><a class="active" href="AdminSession.php">Dashboard</a></li>
        </ul>
    </nav>
<br/>

<section>
    <h1>Manage Patients</h1>
    
</section>

<div class="product-list">



  <?php
	include 'conn.php';
$conn=OpenCon();
if(! $conn ) {
    die('Could not connect: ' . mysql_error());
}

	
$sql = 'SELECT * FROM patient';

 $retval = mysqli_query( $conn,$sql);

mysqli_close($conn);

echo"<table border='1px solid green' style='color:green' cellspacing='10' cellpadding='5' >";
echo"<tr style='background-color: #D6EEEE;'>";
   echo"<td>Patient ID</td>";
echo"<td>Email</td>";   
   echo"<td>Fullname</td>";
   echo"<td>Mobile</td>";
   echo"<td>Gender</td>";
    echo"<td>Age</td>";	
    echo"<td>Password</td>";
	
	 echo"<td>Edit</td>";
	 echo"<td>Delete</td>";
	echo"</tr>";
while($record=mysqli_fetch_array($retval))
{
     $field1=$record['id'];
	 $field2=$record['email'];
	 $field3=$record['fullName'];
	 $field4=$record['phone'];
	 $field5=$record['gender'];
	$field6=$record['age'];
    $field7=$record['password'];	
	
echo"<form action='managePat.php' method='Post'>";
   echo"<tr>";
   echo"<td>"."<input type=text name=txt class=txt readonly value=".$field1.">"."</td>";
   echo"<td>"."<input type=text name=txt1 class=txt readonly value=".$field2.">"."</td>";
   echo"<td>"."<input type=text name=txt2 class=txt  value=".$field3.">"."</td>";
   echo"<td>"."<input type=text name=txt3 class=txt  value=".$field4.">"."</td>";
   echo"<td>"."<input type=text name=txt4 class=txt readonly value=".$field5.">"."</td>";
     echo"<td>"."<input type=text name=txt5 class=txt  value=".$field6.">"."</td>";
   echo"<td>"."<input type=text name=txt6 class=txt readonly value=".$field7.">"."</td>";
   echo"<td><input type=submit name=edit style='width:25;height:20px; border:2px solid white; font-size:medium; background-color:green; color:white' value='Edit' ></td>";
    echo"<td><input type=submit name=delete  style='width:25;height:20px; border:2px solid white; font-size:medium; background-color:red; color:white' value='Delete' ></td>";
    echo"</tr>";
	echo"</form>";
}	

?>


  

</div>


</body>
</html>