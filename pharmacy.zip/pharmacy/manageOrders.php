

<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
    <title>Admin Session</title>
</head>

<body>
   
    <nav>
        <ul class="navbar">
           
            <li><a href="managePatient.php">Manage Patients</a></li>
            <li><a href="manageOrders.php">Manage Orders</a></li>
			  <li><a href="manageItems.php">Manage Medicines</a></li>
			<li><a class="active" href="AdminSession.php">Dashboard</a></li>
        </ul>
    </nav>
<br/>

<section>
    <h1>Admin Dashboard</h1>
    
</section>

<div >

<h1 style="color:#7FBD40;"> Manage Orders </h1>
<br>	


  <?php
	include 'conn.php';
$conn=OpenCon();
if(! $conn ) {
    die('Could not connect: ' . mysql_error());
}

	
$sql = 'SELECT * FROM orders';

 $retval = mysqli_query( $conn,$sql);

mysqli_close($conn);

echo"<table border='1px solid green' style='color:green;width:100%;'  cellspacing='10' cellpadding='10' >";
echo"<tr style='background-color: #D6EEEE;'>";
   echo"<td>ID</td>";  
   echo"<td >Product Details</td>";
   echo"<td>Orders Date</td>";
    echo"<td>Total Price</td>";
	 echo"<td>Pay Method</td>";
	 echo"<td>UserID</td>";
	  echo"<td>Order Status</td>";
	  echo"<td>Confirm</td>";
	  echo"<td>Delete</td>";
	echo"</tr>";
while($record=mysqli_fetch_array($retval))
{
     $field1=$record['ordersID'];
	 $field2=$record['productDetails'];
	 $field3=$record['orderDate'];
	 $field4=$record['totalPrice'];
	 $field5=$record['payMethod'];
	 $field6=$record['customerID'];
	$field7=$record['orderStatus'];
echo"<form action='manageOrder.php' name='orders' method='Post'>";
   echo"<tr >";
  echo"<td>"."<input type=text name=txt class=txt readonly value=".$field1.">"."</td>";
  echo"<td>".$field2."</td>";
  echo"<td >".$field3."</td>";
  echo"<td >".$field4."</td>";
   echo"<td >".$field5."</td>";
   echo"<td>".$field6."</td>";
    echo"<td style='color:red;'>".$field7."</td>";
  echo"<td><input type=submit name=confirm  style='width:25;height:20px; border:2px solid white; font-size:medium; background-color:green; color:white' value='Confirm' ></td>";
    echo"<td><input type=submit name=delete  style='width:25;height:20px; border:2px solid white; font-size:medium; background-color:red; color:white' value='Delete' ></td>";
    echo"</tr>";
	echo"</form>";
}	
 echo"</table>";
?>

</div>

  </body>
</html>