

<?php
include 'conn.php';
$conn=OpenCon();
session_start();
$usr=$_SESSION['userID'];
if(! $conn ) 
{
 die('Could not connect: ' . mysql_error());
}

$sql = "SELECT * from cart";

if ($result = mysqli_query($conn, $sql)) {

    // Return the number of rows in result set
    $rowcount = mysqli_num_rows( $result );
	//echo $rowcount;
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
    <title>Patient Session</title>
	
	
	
	
	<style>
	
	.addToCart
	{
    width: 30px;
	height:30px;
    margin: 10px auto;
    background-color: #FF5733 ;
    padding: 2px;
    border-radius: 15px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    border: 2px solid #FF5733;
    position: relative; /* Required for the pseudo-element */
	color:white;
	font-size:x-large;
	font-wheit:bold;
}
.qty{
		
	border:2px solid #FF5733; 
	font-size:medium;
	width:40px; 
	height:25px;
	padding: 2px;
	text-align: center;
}
	
	</style>
</head>

<body>
   
    <nav>
        <ul class="navbar">
            <li><a href="index.html" class="active"></a></li>
            <li><a class="active" href="allListOrders.php?id=<?php echo $usr;?>">Patient List Orders</a></li>
            <li><a href="services.html">services</a></li>
			<li>
			 <a href="checkOut.php?id=<?php echo $usr;?>"><img src="images/basket.png" width="32px" height="32px" /></a>
</li>
<li>			 
	<input type="text"  name="nbr" style="width:30px" id="nbr" readonly value="<?php echo $rowcount;?>"/> 
			</li>
        </ul>
    </nav>
<br/>
<?php
echo"<h3 style='color:#333'><a href='logOut.php'><img src='images/icon.png'/></a> \t \t" .$usr;
echo"</h3>";
?>
<section>
    <h1>Medicines</h1>
    <p>For more information about medicines</p>
</section>
<form name="frm" action="addToCart.php" method="post">	
<div class="product-list">

    <div class="product-item">
        <img src="images\PanadolforChildren.jpg" alt="Panadol for Children">
        <h3>Panadol for children (5 - 12 years)</h3>
        <p>Elixir 100 ml</p>
        <p class="price">1.500 O.R</p>
		<input type="number" name="qty" id="qty" value="1" min="1" max="5" class="qty" />

            <div >
                <input type="submit" class="addToCart" value="+" name="add"  /> 
            </div>
			 <p> <a href="products/panadolCh.html">More Information's</a></p>
    </div>
    <div class="product-item">
        <img src="images\PanadolAdvance.jpg" alt="Panadol Advance">
        <h3>Panadol Advance Optizorb tablets</h3>
        <p>24 tablets</p>
        <p class="price">0.940 O.R</p>
		<input type="number" name="qty1" id="qty" value="1" min="1" max="5" class="qty" />

            <div >
                <input type="submit" class="addToCart" value="+" name="add1"  /> 
            </div>
			 <p> <a href="products/panadolAd.html">More Information's</a></p>
    </div>
    <div class="product-item">
        <img src="images\RadianMassageCream.jpg" alt="Radian Massage Cream">
        <h3>Radian Massage Cream</h3>
        <p></p>
        <p class="price">0.800 O.R</p>
		<input type="number" name="qty2" id="qty" value="1" min="1" max="5" class="qty" />

            <div >
                <input type="submit" class="addToCart" value="+" name="add2"  /> 
            </div>
			 <p> <a href="products/Radian.html">More Information's</a></p>
    </div>
    <div class="product-item">
        <img src="images\SeastonetherapeuticmedicinefromHimalaya.jpg" alt="Himalaya Cystone">
        <h3>seaston therapeutic drug from Himalaya</h3>
        <p></p>
        <p class="price">2.000 O.R</p>
		<input type="number" name="qty3" id="qty" value="1" min="1" max="5" class="qty" />

            <div >
                <input type="submit" class="addToCart" value="+" name="add3"  /> 
            </div>
			 <p> <a href="products/cystone.html">More Information's</a></p>
    </div>
    <div class="product-item">
        <img src="images\Stripsilsextra.jpg" alt="Himalaya Cystone">
        <h3>STRIPSILS EXTRA</h3>
        <p class="price">2.090 O.R</p>
		<input type="number" name="qty4" id="qty" value="1" min="1" max="5" class="qty" />

            <div >
                <input type="submit" class="addToCart" value="+" name="add4"  /> 
            </div>
			 <p> <a href="products/Stripsils.html">More Information's</a></p>
    </div>
    <div class="product-item">
        <img src="images\Fludrex.jpg" alt="Himalaya Cystone">
        <h3>FLUDREX</h3>
        <p class="price">1.330 O.R</p>
		<input type="number" name="qty5" id="qty" value="1" min="1" max="5" class="qty" />

            <div >
                <input type="submit" class="addToCart" value="+" name="add5"  /> 
            </div>
			 <p> <a href="products/Fludrex.html">More Information's</a></p>
    </div>

</div>

</form>

</body>
</html>