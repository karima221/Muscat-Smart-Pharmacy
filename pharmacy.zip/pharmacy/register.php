
<?php
include 'conn.php';
$conn=OpenCon();
 $valid = 1;
 $error_message="";
 
 if (isset($_POST['cancel'])) {
	
	echo "<script> window.location.href='index.php'</script>";
 }
if (isset($_POST['login'])) {

    $email= $_POST['email'];
    $fullname= $_POST['fullname'];
    $phone= $_POST['phone'];
	$age= $_POST['age'];
    $gender= $_POST['gender'];
    $password=$_POST['password'];
	$re_password=$_POST['rePassword'];
   
 
    if(empty($fullname)) {
        $valid = 0;
        $error_message .= "Invalid Fullname Field"."<br>";
    }

if(empty($phone)) {
        $valid = 0;
        $error_message .= "Invalid phone Number Field"."<br>";
    }
	
if(empty($age)) {
        $valid = 0;
        $error_message .= "Invalid age Field"."<br>";
    }
    if(empty($email)) {
        $valid = 0;
        $error_message .= "Invalid Email Address "."<br>";
    } else {
            $sql="select email from patient where email='$email'";
       $result = mysqli_query($conn,$sql); 
       $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
       $count = mysqli_num_rows($result);                           
            if($count==1) {
                $valid = 0;
                $error_message .= " Patient already Exists"."<br>";
            }
        }
    
    if( empty($password) || empty($re_password) ) {
        $valid = 0;
        $error_message .= "Password and re-password empty"."<br>";
    }

    if( !empty($password) && !empty($re_password) ) {
        if($password != $re_password) {
            $valid = 0;
            $error_message .= "Password and re-passord doesn't mutch"."<br>";
        }
    }

    if($valid == 1) {
		
		 $sql = "INSERT INTO patient(email,fullName,phone,gender,age,password)VALUES('$email','$fullname','$phone','$gender','$age','$password')";
   
    $retval =mysqli_query($conn, $sql) ;
    
    if(! $retval ) {
        die('Could not enter data: ' . mysql_error());
    }
   echo "<script>alert('Successfully Add new Patient !'); window.location.href='index.php';</script>";
       
}
mysqli_close($conn);
		
	}
		
	?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css"/>
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css" />
   <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>
 <script>
   const phoneInputField = document.querySelector("#phone");
   const phoneInput = window.intlTelInput(phoneInputField, {
     utilsScript:
       "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
   });
 </script>
 
 <style>
 
 input[type="text"],
input[type="password"],
input[type="tel"],select {
    width: 100%;
    padding: 10px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #3a9375;
    border-radius: 4px;
    box-sizing: border-box;
}
 
 </style>
</head>
<body>

    <div class="container">
        <img src="images\image2.png" alt="Logo">
        <form action="" method="post">
            <h2>Create An Account</h2>
            <label for="username">Email Address</label>
            <input type="text" id="username" name="email" >
			<label for="username">Patient Name</label>
            <input type="text" id="username" name="fullname" >
			<label for="username">Phone Number</label>
            <input type="tel" id="phone" name="phone"  maxlength="8"  / >
			<label for="username">Gender:</label>
			  <select id="gender" name="gender" >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
				<br/>
				  <label for="password">Age:</label>
            <input type="text" id="" name="age" >
            <label for="password">Password</label>
            <input type="password" id="password" name="password" >
          
 <label for="password">Re-Password</label>
            <input type="password" id="password" name="rePassword" >
		  <button type="submit" name="login">Login</button>
			<br/>
		 <button type="submit" name="cancel">Cancel</button>
			 <br/>
			 <br>
	 <?php
         if($error_message != '') 
		 {
     echo "<div class='error' style='padding: 10px;margin-bottom:20px;color:red'>".$error_message."</div>";
          }
     ?>
        </form>
		
    </div>
	
	
	
	
</body>
</html>
