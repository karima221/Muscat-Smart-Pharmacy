 
 <?php
 
 include 'conn.php';
$conn=OpenCon();

 $targetDir = "images/"; 
 
 $medicinesDetails=$_POST['txtName'];
 $storedDate=date("Y-m-d H:i:s");
 $price=$_POST['txtPrice'];
 $qty=$_POST['txtQty'];
						
 if(isset($_POST['add']))
 {	 
  $fileName = $_FILES['uploadfile']['name'];
    $tempName = $_FILES['uploadfile']['tmp_name'];
    $folder = "./images/" . $fileName;

 $sql = "INSERT INTO medicines (medicinesDetails,storedDate,medicinesPrice,qty,photo)
				VALUES ('$medicinesDetails','$storedDate','$price',' $qty','$folder')"; 
$retval= mysqli_query($conn, $sql) ;
   
    if(! $retval ) {
        die('Could not enter data: ' . mysql_error());
    }
 if (move_uploaded_file($tempName, $folder)) {
        echo "<script>alert('Successfully Add Medicines !'); window.location.href='manageItems.php';</script>";      

	} else {
        echo "<script>alert('Error  !'); window.location.href='manageItems.php';</script>";      
    }
 }
 ?>
 
