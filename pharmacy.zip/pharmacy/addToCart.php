
<?php

include 'conn.php';
$conn=OpenCon();
if(! $conn ) 
{
 die('Could not connect: ' . mysql_error());
}

if(isset($_POST['add']))

 {	  
   $qty= $_POST['qty'];
   $itemName= "Panadol for children (5 - 12 years)";
   $itemID= 1;
   $price= 1.5000;
   $total= (int)$qty*$price; 
 
 $sql = "INSERT INTO cart(item_id,item_name,price,qty,total)VALUES('$itemID','$itemName','$price','$qty','$total')";
    
 $retval =mysqli_query($conn, $sql) ;
     header("location:Home.php"); 
    if(! $retval ) {
        die('Could not enter data: ' . mysql_error());
    }
}
if(isset($_POST['add1']))

 {	  
   $qty1= $_POST['qty1'];
   $itemName= "Panadol Advance Optizorb tablets";
   $itemID= 2;
   $price= 0.940 ;
   $total= (int)$qty1*$price; 
 
 $sql = "INSERT INTO cart(item_id,item_name,price,qty,total)VALUES('$itemID','$itemName','$price','$qty1','$total')";
    
 $retval =mysqli_query($conn, $sql) ;
     header("location:Home.php"); 
    if(! $retval ) {
        die('Could not enter data: ' . mysql_error());
    }
}
if(isset($_POST['add2']))

 {	  
   $qty2= $_POST['qty2'];
   $itemName= "Radian Massage Cream";
   $itemID= 3;
   $price= 0.800 ;
   $total= (int)$qty2*$price; 
 
 $sql = "INSERT INTO cart(item_id,item_name,price,qty,total)VALUES('$itemID','$itemName','$price','$qty2','$total')";
    
 $retval =mysqli_query($conn, $sql) ;
     header("location:Home.php"); 
    if(! $retval ) {
        die('Could not enter data: ' . mysql_error());
    }
}

if(isset($_POST['add3']))

 {	  
   $qty3= $_POST['qty3'];
   $itemName= "seaston therapeutic drug from Himalaya";
   $itemID= 4;
   $price= 2.0;
   $total= (int)$qty3*$price; 
 
 $sql = "INSERT INTO cart(item_id,item_name,price,qty,total)VALUES('$itemID','$itemName','$price','$qty3','$total')";
    
 $retval =mysqli_query($conn, $sql) ;
     header("location:Home.php"); 
    if(! $retval ) {
        die('Could not enter data: ' . mysql_error());
    }
	
 }
	
	if(isset($_POST['add4']))

 {	  
   $qty3= $_POST['qty4'];
   $itemName= "STRIPSILS EXTRA";
   $itemID= 5;
   $price= 2.09 ;
   $total= (int)$qty3*$price; 
 
 $sql = "INSERT INTO cart(item_id,item_name,price,qty,total)VALUES('$itemID','$itemName','$price','$qty3','$total')";
    
 $retval =mysqli_query($conn, $sql) ;
     header("location:Home.php"); 
    if(! $retval ) {
        die('Could not enter data: ' . mysql_error());
    }
	
}

if(isset($_POST['add5']))

 {	  
   $qty3= $_POST['qty5'];
   $itemName= "FLUDREX";
   $itemID= 6;
   $price= 1.330 ;
   $total= (int)$qty3*$price; 
 
 $sql = "INSERT INTO cart(item_id,item_name,price,qty,total)VALUES('$itemID','$itemName','$price','$qty3','$total')";
    
 $retval =mysqli_query($conn, $sql) ;
     header("location:Home.php"); 
    if(! $retval ) {
        die('Could not enter data: ' . mysql_error());
    }
	
}
?>
