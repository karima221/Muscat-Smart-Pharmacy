<?php

session_start();
$usr=$_SESSION['userID'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
    <title>Patient Session</title>
	
	
	
	
	<style>
	
	.addToCart
	{
    width: 30px;
	height:30px;
    margin: 10px auto;
    background-color: #FF5733 ;
    padding: 2px;
    border-radius: 15px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    border: 2px solid #FF5733;
    position: relative; /* Required for the pseudo-element */
	color:white;
	font-size:x-large;
	font-wheit:bold;
}
.qty{
		
	border:2px solid #FF5733; 
	font-size:medium;
	width:40px; 
	height:25px;
	padding: 2px;
	text-align: center;
}
	
	</style>
</head>

<body>
   
    <nav>
        <ul class="navbar">
       
            <li><a href="about.html">about</a></li>
            <li><a href="services.html">services</a></li>

        </ul>
    </nav>
<br/>
<?php

echo"<h3 style='color:#333'><a href='Home.php'><img src='images/icon.png'/></a> \t \t" .$usr;
echo"</h3>";
?>
  
 
<br/>
<br/>


<div class="container">
	
	<p style=" text-align:justifier;font-size:28px; margin:35px; font-weight:bold;" >
	
 All List Orders
	
	</p>
<p>
  <?php
	include 'conn.php';
$conn=OpenCon();
if(! $conn ) {
    die('Could not connect: ' . mysql_error());
}

	
$sql = "SELECT * FROM orders where customerID='$usr'";

 $retval = mysqli_query( $conn,$sql);
 
if(! $retval ) {
    die('Could not enter data: ' . mysql_error());
}

echo"<table collspacing='0' cellspacing='0' border='1px solid blue' style='font-size:medium; color: green'  >";
echo"<tr>";
   echo"<td>ID</td>";
   echo"<td>Details</td>";
   echo"<td>Order Date </td>";
   echo"<td>Total Amount(OMR)</td>";
   echo"<td>Pay Method</td>";
    echo"<td>Customer ID</td>";
	echo"<td>Order Status</td>";
	echo"<td>Action</td>";
    echo"</tr>";
								
while($record=mysqli_fetch_array($retval))
{
     $field1=$record['ordersID'];
	 $field2=$record['productDetails'];
	 $field3=$record['orderDate'];
	 $field4=$record['totalPrice'];
	 $field5=$record['payMethod'];
	 $field6=$record['customerID'];
	 $field7=$record['orderStatus']; 
  echo"<tr>";
   echo"<td>".$field1."</td>";
   echo"<td>".$field2."</td>";
   echo"<td>".$field3."</td>";
   echo"<td>".$field4."</td>";
   echo"<td>".$field5."</td>";
    echo"<td>".$field6."</td>";
	 echo"<td>".$field7."</td>";
echo"<td>"." <a  href=customer-order-delete.php?id=".$field1."&usr=".$usr."> <img src='images/del.png' width='20px' height='20px'/> </a>"."</td>";
    echo"</tr>";
	
}	
 
echo"</table>";
?>

</p>
</div>


	
	<footer>
        <p>&copy; 2024 Smart Pharmacy All rights reserved.</p>
    </footer>
</body>
</html>