
<?php
include 'conn.php';
$conn=OpenCon();
 $valid = 1;
 $error_message="";
if (isset($_POST['login'])) {

    $user= $_POST['username'];  
    $pass=$_POST['password'];

if(empty($pass)) {
        $valid = 0;
        $error_message .= "Invalid Password"."<br>";
    }
    if(empty($user)) {
        $valid = 0;
        $error_message .= "Invalid Email Address "."<br>";
    } 
	
	if ($user=="admin" && $pass=="admin" )
    
    {
        setcookie('User',$user,time()+60*60*7);
        setcookie('pass',$pass,time()+60*60*7);
        session_start();
        $_SESSION['userID']=$user;
        header("location: AdminSession.php");
    }else
	
      $sql="select email from patient where email='$user' and password='$pass' ";
       $result = mysqli_query($conn,$sql); 
       $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
       $count = mysqli_num_rows($result); 
       if($count == 1)
	   {
		setcookie('User',$user,time()+60*60*7);
        setcookie('pass',$pass,time()+60*60*7);
        session_start();
        $_SESSION['userID']=$user;
      header("location:Home.php");
       }
       else{
  $error_message .= "Invalid Email  or password"."<br>";
}   
    
mysqli_close($conn);
		
	}
		
	?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>



    <div class="container">
        <img src="images\image2.png" alt="Logo">
        <form action="" method="post">
            <h2>Login</h2>
            <label for="username">Username</label>
            <input type="text" id="username" name="username" >
            <label for="password">Password</label>
            <input type="password" id="password" name="password" >
            <button type="submit" name="login">Login</button>
			<br/>
			 <p>Don't have an account? <a href="register.php">Register here</a></p>
			 <br/>
			 <br>
	 <?php
         if($error_message != '') 
		 {
     echo "<div class='error' style='padding: 10px;margin-bottom:20px;color:red'>".$error_message."</div>";
          }
      ?>
        </form>
    </div>
	
	
	
	
</body>
</html>
