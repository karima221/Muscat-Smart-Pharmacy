


<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
    <title>Patient Session</title>
	
	
	
	
	<style>
	
	.addToCart
	{
    width: 30px;
	height:30px;
    margin: 10px auto;
    background-color: #FF5733 ;
    padding: 2px;
    border-radius: 15px;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    border: 2px solid #FF5733;
    position: relative; /* Required for the pseudo-element */
	color:white;
	font-size:x-large;
	font-wheit:bold;
}
.qty{
		
	border:2px solid #FF5733; 
	font-size:medium;
	width:40px; 
	height:25px;
	padding: 2px;
	text-align: center;
}
	
	</style>
</head>

<body>
   
    <nav>
        <ul class="navbar">
            <li><a href="index.html" class="active">home</a></li>
            <li><a href="about.html">about</a></li>
            <li><a href="services.html">services</a></li>

        </ul>
    </nav>
<br/>
<?php
session_start();
$usr=$_SESSION['userID'];
echo"<h3 style='color:#333'><a href='#'><img src='images/icon.png'/></a> \t \t" .$usr;
echo"</h3>";
?>
  
 <div class="container">
        

 <?php
include 'conn.php';
$conn=OpenCon();
if(! $conn ) {
    die('Could not connect: ' . mysql_error());
}
	
$sql = 'SELECT * FROM cart';

$total=0;
$result = mysqli_query($conn,'SELECT sum(total) as total FROM cart');
$retval = mysqli_query( $conn,$sql);
 
while ($rows = mysqli_fetch_array($result)) 
{
	$total= $rows['total'];
		
}

echo"<table collspacing='10' cellspacing='10' border='1px solid blue' style='font-size:medium; color: green' >";
echo"<tr>";
   echo"<td>ID</td>";
   echo"<td>Item ID</td>";
   echo"<td>Item Name</td>";
   echo"<td>Price (OMR)</td>";
   echo"<td>Qty</td>";
    echo"<td>Total</td>";
	echo"<td>Action</td>";
    echo"</tr>";
$product_details="";
$dat=date("Y-m-d H:i:s");	
	
while($record=mysqli_fetch_array($retval))
{
     $field1=$record['id'];
	 $field2=$record['item_id'];
	 $field3=$record['item_name'];
	 $field4=$record['price'];
	 $field5=$record['qty'];
	 $field6=$record['total'];
$product_details.="\n Product Name \n:".$field3."\n Qty \n:".$field5."\n Price\n:".$field4."/";	 
  
  echo"<tr>";
   echo"<td>".$field1."</td>";
   echo"<td>".$field2."</td>";
   echo"<td>".$field3."</td>";
   echo"<td>".$field4."</td>";
   echo"<td>".$field5."</td>";
    echo"<td>".$field6."</td>";
echo"<td>"." <a  href=cart-item-delete.php?id=".$field1."&usr=".$usr."> <img src='images/del.png' width='20px' height='20px'/> </a>"."</td>";
    echo"</tr>";
	
}	
echo"<tr>";
   echo"<td >Total Price (OMR)</td>";
   echo"<td colspan='5'>".$total."</td>";
  echo"</tr>"; 
echo"</table>";
?>

</div>
<br/>
<br/>
  <div class="container">

<form name="frm" method="post" action="add_order.php">

  <div class="form-group">
                <label for="payment">Payment Method:</label>
                <select id="payment" name="payment" required>
                    <option value="cash">Cash</option>
                    <option value="visa">Visa (coming soon)</option>
                </select>
            </div>
<input type="hidden" name="total" value="<?php echo $total;?>" /> 
<input type="hidden" name="date_order" value="<?php echo $dat;?>" />
<input type="hidden" name="prod_details" value="<?php echo $product_details;?>" />
<input type="hidden" name="customerID" value="<?php echo $usr;?>" />
<br/>
<br/>
<p>

   <button type="submit" name="add" style="width:150px;background-color:green;color:white">Submit Order</button>

<button type="submit" name="add1" style="width:150px;background-color:gray;color:white">Continuous </button>
<button type="submit" name="cancel" style="width:150px;background-color:red;color:white">Cancel</button>

</p>
</form>

</div>      
		
		
</form>
	
	<footer>
        <p>&copy; 2024 Smart Pharmacy All rights reserved.</p>
    </footer>
</body>
</html>