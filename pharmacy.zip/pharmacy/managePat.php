 <?php
include 'conn.php';
$conn=OpenCon();

    $user=$_POST['txt'];
    $fullName=$_POST['txt2'];
	$phone=$_POST['txt3'];

if(isset($_POST['delete']))
{   
 mysqli_query($conn,"delete from  patient where id='$user'" );
 echo "<script>alert('Successfully remove Patient !'); window.location.href='managePatient.php';</script>";      

}
if(isset($_POST['edit']))
{   

$sql = "UPDATE patient SET fullName='$fullName', phone='$phone'  WHERE id='$user'";

if ($conn->query($sql) === TRUE) 
{
 echo "<script>alert('Successfully Update Patient !'); window.location.href='managePatient.php';</script>";      

} 
else
	{
 echo "<script>alert('Error edit user !'); window.location.href='managePatient.php';</script>";      

}
 
}
?>