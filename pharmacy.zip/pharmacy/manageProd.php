  <?php
include 'conn.php';
$conn=OpenCon();

    $id=$_POST['txt'];
    $itemName=$_POST['txt1'];
	$itemPrice=$_POST['txt3'];
    
if(isset($_POST['delete']))
{   
 mysqli_query($conn,"delete from  medicines where medicinesID='$id'" );
 echo "<script>alert('Successfully remove Medicines !'); window.location.href='manageItems.php';</script>";      

}
if(isset($_POST['edit']))
{   

$sql = "UPDATE medicines SET medicinesDetails='$itemName', medicinesPrice='$itemPrice'  WHERE medicinesID='$id'";

if ($conn->query($sql) === TRUE) 
{
 echo "<script>alert('Successfully Update Medicines !'); window.location.href='manageItems.php';</script>";      

} 
else
	{
 echo "<script>alert('Error edit med !'); window.location.href='manageItems.php';</script>";      

}
 
}

?>