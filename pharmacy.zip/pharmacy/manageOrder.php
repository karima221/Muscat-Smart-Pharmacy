   <?php
include 'conn.php';
$conn=OpenCon();

    $ordersID=$_POST['txt'];
   $status="Ready";
if(isset($_POST['delete']))
{   
 mysqli_query($conn,"delete from  orders where ordersID='$ordersID'" );
 echo "<script>alert('Successfully remove Orders !'); window.location.href='manageOrders.php';</script>";      

}
if(isset($_POST['confirm']))
{   
 $sql = "UPDATE orders SET orderStatus='$status' WHERE ordersID='$ordersID'";

if ($conn->query($sql) === TRUE) 
{
 echo "<script>alert('Successfully Update Orders !'); window.location.href='manageOrders.php';</script>";      

} 
else
	{
 echo "<script>alert('Error edit Order !'); window.location.href='manageOrders.php';</script>";      

}
}
?>