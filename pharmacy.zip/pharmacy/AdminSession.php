
<?php
include 'conn.php';
$conn=OpenCon();
if(! $conn ) 
{
 die('Could not connect: ' . mysql_error());
}

$sql = "SELECT * from patient";

if ($result = mysqli_query($conn, $sql)) {

    // Return the number of rows in result set
    $total_users = mysqli_num_rows( $result );
	
}
$sql = "SELECT * from medicines";

if ($result = mysqli_query($conn, $sql)) {

    // Return the number of rows in result set
    $total_prod = mysqli_num_rows( $result );
	
}
$sql = "SELECT * from orders";

if ($result = mysqli_query($conn, $sql)) {

    // Return the number of rows in result set
    $total_orders = mysqli_num_rows( $result );
	
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/style.css">
    <title>Admin Session</title>
</head>

<body>
   
    <nav>
        <ul class="navbar">
             <li><a href="managePatient.php">Manage Patients</a></li>
            <li><a href="manageOrders.php">Manage Orders</a></li>
			  <li><a href="manageItems.php">Manage Medicines</a></li>
			<li><a class="active" href="AdminSession.php">Dashboard</a></li>
        </ul>
    </nav>
<br/>
<?php 
session_start();
$usr=$_SESSION['userID'];
echo"<h3 style='color:#333'><a href='logOut.php'><img src='images/icon.png'/></a> \t \t" .$usr;
echo"</h3>";
?>
<section>
    <h1>Admin Dashboard</h1>
    
</section>

<div class="product-list">





<div class="product-item">
       
	   
	   <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="big-box bg-secondary" style="padding-left: 20px; ">
                <div class="inner">
                  <h2><?php echo $total_users; ?></h2>

                  <p style="color:#333;font-size:24px">Users</p>
                </div>
               
              </div>
            </div> 
	   
	   
    </div>
  
   <div class="product-item">
       
	 <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="big-box bg-primary" style="padding-left: 50px; ">
                <div class="inner">
                  <h2><?php echo $total_orders; ?></h2>

                  <p style="color:#333;font-size:24px">Orders</p>
                </div>
              
              </div>
            </div>	
	   
	   
    </div> 
  <div class="product-item">
       
	<div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="big-box bg-primary" style="padding-left: 50px; ">
                <div class="inner">
                  <h2><?php echo $total_prod; ?></h2>

                  <p style="color:#333;font-size:24px">Products(Medicines)</p>
                </div>
               
              </div>
            </div>	
	   
	   
    </div> 
</div>


</body>
</html>